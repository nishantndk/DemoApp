var app = angular.module('ngexampletable', []);

//var timearray="[{'ts':'09:30:00'},{'ts':'10:00:00'},{'ts':'10:30:00'},{'ts':'11:00:00'},{'ts':'11:30:00'},{'ts':'12:00:00'},{'ts':'12:30:00'},{'ts':'13:00:00'},{'ts':'14:00:00'},{'ts':'14:30:00'},{'ts':'15:00:00'}]";
//$scope.timearray = $scope.$eval(timearray);

app.controller('MainCtrl', function($scope, $http) {
    $http.get("http://localhost:8182/data/GetBANKNIFTYCEChain.json")
    .then(function(response) {
        $scope.tableDataCE  = response.data;
    });
    
    $http.get("http://localhost:8182/data/GetBANKNIFTYPEChain.json")
    .then(function(response) {
        $scope.tableDataPE  = response.data;
    });
    
    $http.get("http://localhost:8182/data/GetFUT.json")
    .then(function(response) {
        $scope.tableDataFUT  = response.data;
    });
    
    $http.get("http://localhost:8182/data/GetNIFTYCEChain.json")
    .then(function(response) {
        $scope.tableDataNIFTYCE  = response.data;
    });
    
    $http.get("http://localhost:8182/data/GetNIFTYPEChain.json")
    .then(function(response) {
        $scope.tableDataNIFTYPE  = response.data;
    });
    
    $http.get("http://localhost:8182/data/tradedate.json")
    .then(function(response) {
        $scope.tradedate  = response.data;
    });
    
    $http.get("http://localhost:8182/data/tradetime.json")
    .then(function(response) {
        $scope.tradetime  = response.data;
    });
    
    $http.get("http://localhost:8182/data/GetBANKNIFTYCETTSQ.json")
    .then(function(response) {
        $scope.ttsqce  = response.data[0].ttsq;
    });
    
    $http.get("http://localhost:8182/data/GetBANKNIFTYPETTSQ.json")
    .then(function(response) {
        $scope.ttsqpe  = response.data[0].ttsq;
    });
    
});


function toggle_highlight(inputTagReference) {
	var is_checked = inputTagReference.checked; //true or false
	if(is_checked) {
		inputTagReference.parentNode.parentNode.style.backgroundColor="orange";
	}
	else {
		inputTagReference.parentNode.parentNode.style.backgroundColor="";
	}
}



