var express = require('express');
var app = express();
var http = require('http');
var fs = require('fs');
var path = require('path');

var mysql = require('mysql');

var conn = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : 'passw0rd',
    database : 'RTDB'
});

conn.connect();

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

app.get('/GetFUT', function(request, response){
    conn.query("select uid , instrument ,symbol ,expirydt ,strikepr ,optiontyp ,open , high ,low , close , pclose , vwap , volume , openint ,chginoi , tbq,tsq,tradedate ,tradetime, ts from FNORT where ts =(select  ts from FNORT where islocked='N' order by ts desc limit 1)  and optiontyp = 'XX' order by strikepr desc ", function(error, results){
        if ( error ){
            response.status(400).send('Error in database operation');
        } else {
            response.send(results);
        }
    });
});

app.get('/GetBANKNIFTYCEChain', function(request, response){
    conn.query("select uid , instrument ,symbol ,expirydt ,strikepr ,optiontyp ,open , high ,low , close , pclose , vwap , volume , openint ,chginoi , tbq,tsq,tradedate ,tradetime, ts from FNORT where ts =(select  ts from FNORT where islocked='N' order by ts desc limit 1)  and optiontyp = 'CE' and symbol = 'BANKNIFTY' order by strikepr desc ", function(error, results){
        if ( error ){
            response.status(400).send('Error in database operation');
        } else {
            response.send(results);
        }
    });
});

app.get('/GetBANKNIFTYCETTSQ', function(request, response){
    conn.query("select sum(tsq) as ttsq from FNORT where ts =(select  ts from FNORT where islocked='N' order by ts desc limit 1)  and optiontyp = 'CE' and symbol = 'BANKNIFTY' order by strikepr desc ", function(error, results){
        if ( error ){
        console.error();
            response.status(400).send('Error in database operation');
            
        } else {
            response.send(results);
        }
    });
});


app.get('/GetBANKNIFTYPEChain', function(request, response){
    conn.query("select uid , instrument ,symbol ,expirydt ,strikepr ,optiontyp ,open , high ,low , close , pclose , vwap , volume , openint ,chginoi , tbq,tsq,tradedate ,tradetime, ts  from FNORT where ts =(select  ts from FNORT where islocked='N' order by ts desc limit 1)  and optiontyp = 'PE' and symbol = 'BANKNIFTY' order by strikepr desc ", function(error, results){
        if ( error ){
            response.status(400).send('Error in database operation');
        } else {
            response.send(results);
        }
    });
});

app.get('/GetBANKNIFTYPETTSQ', function(request, response){
    conn.query("select sum(tsq) as ttsq from FNORT where ts =(select  ts from FNORT where islocked='N' order by ts desc limit 1)  and optiontyp = 'PE' and symbol = 'BANKNIFTY' order by strikepr desc ", function(error, results){
        if ( error ){
        console.error();
            response.status(400).send('Error in database operation');
            
        } else {
            response.send(results);
        }
    });
});

app.get('/GetNIFTYCEChain', function(request, response){
    conn.query("select uid , instrument ,symbol ,expirydt ,strikepr ,optiontyp ,open , high ,low , close , pclose , vwap , volume , openint ,chginoi , tbq,tsq,tradedate ,tradetime, ts  from FNORT where ts =(select  ts from FNORT  where islocked='N' order by ts desc limit 1)  and optiontyp = 'CE' and symbol = 'NIFTY' order by strikepr desc ", function(error, results){
        if ( error ){
            response.status(400).send('Error in database operation');
        } else {
            response.send(results);
        }
    });
});

app.get('/GetNIFTYPEChain', function(request, response){
    conn.query("select uid , instrument ,symbol ,expirydt ,strikepr ,optiontyp ,open , high ,low , close , pclose , vwap , volume , openint ,chginoi , tbq,tsq,tradedate ,tradetime, ts  from FNORT where ts =(select  ts from FNORT  where islocked='N'  order by ts desc limit 1)  and optiontyp = 'PE' and symbol = 'NIFTY' order by strikepr desc ", function(error, results){
        if ( error ){
            response.status(400).send('Error in database operation');
        } else {
            response.send(results);
        }
    });
});

app.get('/GetBANKNIFTYCEChain1330', function(request, response){
    conn.query("select uid , instrument ,symbol ,expirydt ,strikepr ,optiontyp ,open , high ,low , close , pclose , vwap , volume , openint ,chginoi , tbq,tsq,tradedate ,tradetime, ts  from FNORT where ts =(select  ts from FNORT  where islocked='N' and tradetime <= '13:30:00' order by ts desc limit 1)  and optiontyp = 'CE' and symbol = 'BANKNIFTY' order by strikepr desc ", function(error, results){
        if ( error ){
            response.status(400).send('Error in database operation');
        } else {
            response.send(results);
        }
    });
});

app.get('/GetBANKNIFTYPEChain1330', function(request, response){
    conn.query("select uid , instrument ,symbol ,expirydt ,strikepr ,optiontyp ,open , high ,low , close , pclose , vwap , volume , openint ,chginoi , tbq,tsq,tradedate ,tradetime, ts from FNORT where ts =(select  ts from FNORT  where islocked='N' and tradetime <= '13:30:00' order by ts desc limit 1)  and optiontyp = 'PE' and symbol = 'BANKNIFTY' order by strikepr desc ", function(error, results){
        if ( error ){
            response.status(400).send('Error in database operation');
        } else {
            response.send(results);
        }
    });
});


app.get('/GetBANKNIFTYCEChain1430', function(request, response){
    conn.query("select uid , instrument ,symbol ,expirydt ,strikepr ,optiontyp ,open , high ,low , close , pclose , vwap , volume , openint ,chginoi , tbq,tsq,tradedate ,tradetime, ts  from FNORT where ts =(select  ts from FNORT  where islocked='N' and tradetime <= '14:30:00' order by ts desc limit 1)  and optiontyp = 'CE' and symbol = 'BANKNIFTY' order by strikepr desc ", function(error, results){
        if ( error ){
            response.status(400).send('Error in database operation');
        } else {
            response.send(results);
        }
    });
});

app.get('/GetBANKNIFTYPEChain1430', function(request, response){
    conn.query("select uid , instrument ,symbol ,expirydt ,strikepr ,optiontyp ,open , high ,low , close , pclose , vwap , volume , openint ,chginoi , tbq,tsq,tradedate ,tradetime, ts  from FNORT where ts =(select  ts from FNORT  where islocked='N' and tradetime <= '14:30:00' order by ts desc limit 1)  and optiontyp = 'PE' and symbol = 'BANKNIFTY' order by strikepr desc ", function(error, results){
        if ( error ){
            response.status(400).send('Error in database operation');
        } else {
            response.send(results);
        }
    });
});

app.get('/test/:ts', function(request, response){
    var tst = request.params.ts;
    console.log('ts= > '+tst);
    conn.query("select uid , instrument ,symbol ,expirydt ,strikepr ,optiontyp ,open , high ,low , close , pclose , vwap , volume , openint ,chginoi , tbq,tsq,tradedate ,tradetime, ts  from FNORT where ts =(select  ts from FNORT  where islocked='N'  order by ts desc limit 1)  and optiontyp = 'XX' order by strikepr desc ", function(error, results){
        if ( error ){
       		 console.error();
            response.status(400).send('Error in database operation');
        } else {
            response.send(results);
        }
    });
});


app.get('/tradetime', function(request, response){
    conn.query("SELECT distinct ts FROM FNORT WHERE tradedate=(select  tradedate from FNORT order by tradedate desc limit 1) ORDER BY ts ASC ", function(error, results){
        if ( error ){
            response.status(400).send('Error in database operation');
        } else {
            response.send(results);
        }
    });
});

app.get('/tradetime/:tradedate', function(request, response){
	var tradedate = request.params.tradedate;
	console.log(tradedate);
    conn.query("SELECT distinct ts FROM FNORT WHERE tradedate='"+ tradedate+"' ORDER BY ts ASC ", function(error, results){
        if ( error ){
            response.status(400).send('Error in database operation');
        } else {
            response.send(results);
        }
    });
});

app.get('/tradedate', function(request, response){
    conn.query("SELECT distinct tradedate FROM FNORT ORDER BY tradedate DESC ", function(error, results){
        if ( error ){
            response.status(400).send('Error in database operation');
        } else {
            response.send(results);
        }
    });
});


app.listen(8181, function () {
   console.log('REST Server running at http://127.0.0.1:8181/');
});


http.createServer(function (request, response) {
    //console.log('request starting...');
    response.setHeader('Access-Control-Allow-Origin', '*');
    
    var filePath = '.' + request.url;
    if (filePath == './')
        filePath = './index.html';

    var extname = path.extname(filePath);
    var contentType = 'text/html';
    switch (extname) {
        case '.js':
            contentType = 'text/javascript';
            break;
        case '.css':
            contentType = 'text/css';
            break;
        case '.json':
            contentType = 'application/json';
            break;
        case '.png':
            contentType = 'image/png';
            break;      
        case '.jpg':
            contentType = 'image/jpg';
            break;
        case '.wav':
            contentType = 'audio/wav';
            break;
    }

    fs.readFile(filePath, function(error, content) {
        if (error) {
            if(error.code == 'ENOENT'){
                fs.readFile('./404.html', function(error, content) {
                    response.writeHead(200, { 'Content-Type': contentType });
                    response.end(content, 'utf-8');
                });
            }
            else {
                response.writeHead(500);
                response.end('Sorry, check with the site admin for error: '+error.code+' ..\n');
                response.end(); 
            }
        }
        else {
            response.writeHead(200, { 'Content-Type': contentType });
            response.end(content, 'utf-8');
        }
    });

}).listen(8182);
console.log('HTTP Server running at http://127.0.0.1:8182/');


